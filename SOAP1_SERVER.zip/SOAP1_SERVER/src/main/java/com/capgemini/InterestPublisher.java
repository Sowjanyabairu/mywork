package com.capgemini;

import javax.xml.ws.Endpoint;

public class InterestPublisher {

	public static void main(String[] args) {
		
		Endpoint.publish("http://localhost:7702/ws/interest", new InterestImpl());

	}

}
