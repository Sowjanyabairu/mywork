package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.CalculateSimpleInterest")
public class InterestImpl implements CalculateSimpleInterest{

	@Override
	public Double simpleInterest(Double principle, Double Time, Double Interest) {
		
		return (principle*Time*Interest)/100;
	}
	

	
}
