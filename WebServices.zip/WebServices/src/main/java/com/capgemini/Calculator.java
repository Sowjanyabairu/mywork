package com.capgemini;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;



@SOAPBinding(style=Style.DOCUMENT)
@WebService
public interface Calculator {

	@WebMethod
	public int addNum(int num1,int num2);
	
}
