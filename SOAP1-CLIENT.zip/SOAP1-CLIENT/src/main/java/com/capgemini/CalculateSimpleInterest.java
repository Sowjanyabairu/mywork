package com.capgemini;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@SOAPBinding(style=Style.RPC)
@WebService

public interface CalculateSimpleInterest{
	
	

		@WebMethod
		public Double simpleInterest(Double principle,Double Time,Double Interest);
		
		
		

	}



