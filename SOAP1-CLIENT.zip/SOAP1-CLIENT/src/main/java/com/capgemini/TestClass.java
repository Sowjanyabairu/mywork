package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class TestClass {

	public static void main(String[] args) throws MalformedURLException {
		URL url=new URL("http://localhost:7702/ws/interest?wsdl");
		
		QName qname=new QName("http://capgemini.com/","InterestImplService");
		
		Service service=Service.create(url,qname);
		CalculateSimpleInterest calculate=service.getPort(CalculateSimpleInterest.class);
		System.out.println(calculate.simpleInterest(3000.00, 3.0, 7.0)); 
		
	}

}
