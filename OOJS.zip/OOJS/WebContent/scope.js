/**
 * 
 */
var count=100

var myFun=function calculate(){
	//100
	console.log(count)
	var count=50;
	
	//50
	console.log(count)
	
}