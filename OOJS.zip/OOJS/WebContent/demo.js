/**
 * 
 */
function employee(empId,empName,salary){
	var emp={};
	emp.empId=empId;
	emp.empName=empName;
	emp.salary=salary;
	return emp;
}


var empobj=employee(1001,'Sowji',45000)
console.log('EmployeeId:' +  emp.empId)
console.log('EmployeeName:' +  emp.empName)

console.log('EmployeeSalary:' +  emp.salary)
