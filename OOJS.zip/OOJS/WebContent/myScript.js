/**
 * 
 */
function employee(empId,empName,salary){
	
	this.empId=empId;
	this.firstName=firstName;
	this.lastName=lastName;
	this.salary=salary;
	
	

}

var emp=new employee(1001,'sowji','bairu',45000)
console.log('Employee Id:' +  emp.empId)
console.log('Employee firstName:' +  emp.firstName)
console.log('Employee lastName:' +  emp.lastName)
console.log('Employee salary:' +  emp.salary)

console.log('Employee fullName:' +  emp.getName)