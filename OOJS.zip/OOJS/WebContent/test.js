/**
 * 
 */

var emp=new Object({
empId:1001,
empName:'sowji',
salary:35000,
greet:function(){
	
	
}








})

