/**
 * 
 */
var emp=[
	{
		
		"empid":1001,
		"empName":"sowji",
		"department":["sales","purchase"],
		"isPermanent":true,
		"address":{
			
			"stName":"31/D,Bowenpally",
				"city":"chennai",
				"pincode":"628003"
		}
},
{
	

	"empid":1007,
	"empName":"chinnu",
	"department":["sales","finance"],
	"isPermanent":false,
	"address":{
		
		"stName":"351/A, South Avenue",
			"city":"chennai",
			"pincode":"628067"
	}





}



]