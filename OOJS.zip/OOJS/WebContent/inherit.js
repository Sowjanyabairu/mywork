/**
 * 
 */
function Employee(name){
	this.name=name
}
employee.prototype.getName=function(){
	return this.name;
}

function Department(name,manager){
	this.name=name;
	this.manager=manager;
}
Department.prototype.getDepMgr=function(){
	return this.manager;
}


var emp=new Employee('Jack')
console.log(emp)
console.log(emp.getName())


var dep=new Department('sales','sowji')
console.log(dep)
console.log(dep.getDepMger())

/*dep._proto_=emp
var dep=new Department('sales','sowji')
console.log(dep)
console.log(dep.getgetName())
console.log(dep._proto_.getName())
console.log(dep.getDepMgr())*/

Department.prototype=new Employee('chinni')
var dep=new Department('sales','Annie')
console.log(dep.getName())

