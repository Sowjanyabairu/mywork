/**
 * 
 */
function employee(empId,empName,salry){
	this.empId=empId;
	this.empName=empName;
	this.salary=salary;
	
	
	
 this.getEmpId=function getEmpId(){
	 return this.empId;
 }
 this.getEmpName=function getEmpName(){
	 return this.empName;	
 
 }
 this.getEmpSalary=function getSalary(){
	 return this.salary;
 
 }
 this.setEmpId=function setEmpId(empId){
	 this.empId=empId;
 }
 
 this.setEmpName=function setEmpName(empName){
	 this.empName=empName;
 }
 this.setSalary=function setSalary(salary){
	 this.salary=salary;
 }
 
 
 var empObj=new employee()
 empObj.setEmpId(1001)
 empObj.setEmpName('sowji')
 empObj.setSalary(45000)
 console.log('hello')
 console.log(empObj.getEmpName)


 
 
 
	}
