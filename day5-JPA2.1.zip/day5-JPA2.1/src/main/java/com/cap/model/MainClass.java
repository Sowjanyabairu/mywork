package com.cap.model;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args)
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager =emf.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		
		transaction.begin();
		Customer tom=new Customer("tom","jerry",3560.00,LocalDate.of(2011, 10, 12));
		
		Address address=new Address(4001,"MIPL",tom);
		
		Customer jack=new Customer("jack","jill",3560.00,LocalDate.of(2013, 12, 15));
		Address address1=new Address(4002,"MIPL",jack);
		
		
		
		transaction.commit();
		
}
	
}
