package com.capgemini.dao;

import com.capgemini.model.LoginBean;

public interface ILoginDao {
	public abstract boolean checkUser(LoginBean loginBean);
}




