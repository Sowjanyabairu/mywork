package com.capgemini.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.model.LoginBean;


public class LoginDao implements ILoginDao {

	@Override
	public boolean checkUser(LoginBean loginBean) {
		String sql="select userName,userPwd from adminlogin where userName=? and userPwd=?";
		boolean flag = false;
		try(PreparedStatement ps =getSQLConnection().prepareStatement(sql);){

			ps.setString(1, loginBean.getUserName());
			ps.setString(2, loginBean.getUserPwd());
			ResultSet rs =ps.executeQuery();
			
			while(rs.next()) {
				
				if(rs.getString("userName").equals(loginBean.getUserName())&&rs.getString("userPwd").equals(loginBean.getUserPwd())) {
				flag=true;	
				return flag;
				}
				flag=false;
				} 
}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;


	}
	private Connection getSQLConnection()
	{
		Connection con=null;
		try{


			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/capdb","root","India123");
			return con;
		}catch(SQLException e)
		{
			e.printStackTrace();
		}catch(Exception e1) {
			e1.printStackTrace();
		}

		return con;
	}
} 