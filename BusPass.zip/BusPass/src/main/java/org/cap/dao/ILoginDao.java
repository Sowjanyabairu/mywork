package org.cap.dao;

import org.cap.bean.BusBean;
import org.cap.bean.LoginBean;

public interface ILoginDao {
	public boolean isValidLogin(LoginBean loginBean);
	public BusBean createRequest(BusBean busBean);
}
