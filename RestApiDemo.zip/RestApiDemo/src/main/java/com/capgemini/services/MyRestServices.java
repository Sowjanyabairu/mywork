package com.capgemini.services;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.capgemini.dao.IproductDao;
import com.capgemini.dao.ProductDaoImpl;
import com.capgemini.model.Product;

@Path("/api")
public class MyRestServices {
	
	private IproductDao iproductDao=new ProductDaoImpl();
	
	@GET
	@Path("/delproducts/{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> deleteProduct(@PathParam("productId")Integer productId){
		List<Product> products=iproductDao.deleteProduct(productId);
		return products;
	} 
	
	@POST
	@Path("/addproducts")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> addProduct(@FormParam("productId")Integer productId,
		
		@FormParam("productName") String productName){
		List<Product> products=iproductDao.addProducts(productId,productName);
		return products;
	}
	
	@PUT
	@Path("/findproducts/{productId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Product finfProduct(@PathParam("productId")Integer productId){
		

	Product products=iproductDao.findProducts(productId);
		return products;
	}
	
	

	@POST
	@Path("/updateProducts/{productId}{productName}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> updateProducts(@PathParam("productId") Integer productId, @PathParam("productName") String productName) {
		List<Product> products = iproductDao.updateProducts(productId,productName);
		return products;
	}


	
	@GET
	@Path("/products")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts(){
		return iproductDao.getAllProducts();
	}
	
	
	
	
	
	
	@GET
	@Path("/hello")
	public String sayHello() {
		return "Hello World! from RestAPI";
	}

	
	
	@GET
	@Path("/greet/{userName}")
	@Produces(MediaType.TEXT_HTML)
	public String greetUser(@PathParam("userName") String myUser) {
		
		return "<h1 style='color:red;'>Hello! " + myUser +"</h1>";
	}
	
	
	@GET
	@Path("/loaddata")
	@Produces(MediaType.TEXT_XML)
	public String getXml() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<employee>"
				+ "<firstname>tom</firstname>"
				+ "<lastname>jack</lastname>"
				+ "<age>23</age>"
				+ "</employee>";
	}
	
	@GET
	@Path("/loadjson")
	@Produces(MediaType.APPLICATION_JSON)
	public String getJSON() {
		return "{"
				+ "\"firstname\":\"tom\","
				+ "\"lastname\":\"jerry\","
				+ "\"age\":25"
				+ "}";
	}
	
	

}
