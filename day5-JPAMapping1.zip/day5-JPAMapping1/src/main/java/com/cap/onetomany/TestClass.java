package com.cap.onetomany;

import com.cap.model.EntityManager;
import com.cap.model.EntityManagerFactory;
import com.cap.model.EntityTransaction;

public class TestClass {

	public static void main(String[] args) {
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		
		Company company1=new Company("TCS");
		Company company2=new Company("Capgemini");
		Company company3=new Company("Infosys");
		
		Employee employee1=new Employee(1001,"sowji",company1);
		Employee employee2=new Employee(1002,"chinnu",company2);
		Employee employee3=new Employee(1003,"ravali",company3);
		
		
		
		entityManager.persist();
		entityManager.persist();
		
		
		entityManager.persist();
		entityManager.persist();
		
		entityManager.persist();
		entityManager.persist();

	}

}
