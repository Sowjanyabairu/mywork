package com.cap.onetomany;

import java.util.ArrayList;
import java.util.List;

public class Company {
	private int comapnyId;
	private String companyName;
	
	@oneTomany(mappedBy="company",targetEntity=Employee.class,cascade=cascadeType,ALL,fetch=FetchType.LAZY)
	private List<Employee> empList=new ArrayList<>();
	
	
	public Company() {
		
	}


	public Company(int comapnyId, String companyName, List<Employee> empList) {
		super();
		this.comapnyId = comapnyId;
		this.companyName = companyName;
		this.empList = empList;
	}


	public int getComapnyId() {
		return comapnyId;
	}


	public void setComapnyId(int comapnyId) {
		this.comapnyId = comapnyId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public List<Employee> getEmpList() {
		return empList;
	}


	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}


	@Override
	public String toString() {
		return "Company [comapnyId=" + comapnyId + ", companyName=" + companyName + ", empList=" + empList + "]";
	}

}
