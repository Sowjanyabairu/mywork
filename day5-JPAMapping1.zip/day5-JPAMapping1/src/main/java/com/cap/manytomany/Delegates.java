package com.cap.manytomany;

import java.util.ArrayList;
import java.util.List;

public class Delegates {
	private int delegateId;
	private String delegateName;
	
	
	
	private List<Delegates> delegates=new ArrayList<>();
	
	public Delegates() {
		
	}

	public Delegates(int delegateId, String delegateName, List<Delegates> delegates) {
		super();
		this.delegateId = delegateId;
		this.delegateName = delegateName;
		this.delegates = delegates;
	}

	public int getDelegateId() {
		return delegateId;
	}

	public void setDelegateId(int delegateId) {
		this.delegateId = delegateId;
	}

	public String getDelegateName() {
		return delegateName;
	}

	public void setDelegateName(String delegateName) {
		this.delegateName = delegateName;
	}

	public List<Delegates> getDelegates() {
		return delegates;
	}

	public void setDelegates(List<Delegates> delegates) {
		this.delegates = delegates;
	}

	@Override
	public String toString() {
		return "Delegates [delegateId=" + delegateId + ", delegateName=" + delegateName + ", delegates=" + delegates
				+ "]";
	}
	

}
