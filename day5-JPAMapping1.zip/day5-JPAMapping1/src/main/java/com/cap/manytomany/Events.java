package com.cap.manytomany;

import java.util.ArrayList;
import java.util.List;

public class Events {
	private String eventId;
	private String eventName;
	
	@ManyToMany(name="event_delegate",joincolumns="events");
	inverseJoinColumns= {@JoinColumn(name="events_id")};
	private List<Events> events=new ArrayList<>();
	
	
	
	
	public Events(String eventId, String eventName) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
	}

	
}
