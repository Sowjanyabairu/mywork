package com.cap.manytomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
public class Tester {

	public static void main(String[] args) {
EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		Events servlets=new Events(123,"servlets");
		Events iot=new Events(456,"iot");
		Events python=new Events(789,"python");
		
		
		Delegates delegates1=new Delegates(1,"Sowji");
		Delegates delegates1=new Delegates(2,"tom");
		Delegates delegates1=new Delegates(3,"jerry");
		
		
		delegates1.getEvents().add(servlets);
		delegates1.getEvents().add(iot);
		delegates2.getEvents().add(python);
		delegates1.getEvents().add();
		
		
		
		

	}

}
