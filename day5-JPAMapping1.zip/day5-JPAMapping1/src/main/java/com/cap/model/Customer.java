package com.cap.model;

public class Customer {
	private int custId;
	private String firstName;
	private String lastName;
	private Double regFees;
	
	public Customer() {
		
	}
	
	public Customer(int custId, String firstName, String lastName, Double regFees) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFees = regFees;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Double getRegFees() {
		return regFees;
	}

	public void setRegFees(Double regFees) {
		this.regFees = regFees;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regFees="
				+ regFees + "]";
	}
	
	
	

}
