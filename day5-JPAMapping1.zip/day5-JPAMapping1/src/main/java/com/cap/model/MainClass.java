package com.cap.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cap.demo.Customer;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		
		
		
		Customer customer=new Customer(1001,"sowji",2500.00);
		Address address1=new Address(1001,"Hyd",)
		Customer customer1=new Customer(1002,"chinnu",3200.00);
		Customer customer2=new Customer(1003,"indhu",3500.00);
		
	}

}
