package com.cap.demo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Customer {
	@Id
	private int customerId;
	private String customerName;
	private Double regFees;
	private Date regDate;
		
	public Customer() {
		
	}

	public Customer(int customerId, String customerName, Double regFees, Date regDate) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.regFees = regFees;
		this.regDate = regDate;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Double getRegFees() {
		return regFees;
	}

	public void setRegFees(Double regFees) {
		this.regFees = regFees;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", regFees=" + regFees
				+ ", regDate=" + regDate + "]";
	}
	
}
